# Rana WhatsApp Bot

Auto-reply with GPT. Deploy to Railway, scan QR, go live.

Run locally:
```bash
npm install
npm start
```